from transformers import cache
cache.clear()